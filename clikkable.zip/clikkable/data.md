<!-- data.md -->
# Biolink Configuration

## Profile
- **Name**: Wayne
- **Username**: @waynebkk
- **Hero Image**: img/profile.jpg

## Social Links
- **TikTok**:
  - Icon: https://cdn-icons-png.flaticon.com/512/3046/3046121.png
  - URL: https://tiktok.com/@waynebkk

- **GitHub**:
  - Icon: https://cdn-icons-png.flaticon.com/512/733/733553.png
  - URL: https://github.com/waynebkk

# - **YouTube**:
#  - Icon: https://cdn-icons-png.flaticon.com/512/1384/1384060.png
#  - URL: https://youtube.com/@YOURUSERNAME
  
# - **Email**:
#  - Icon: https://cdn-icons-png.flaticon.com/512/732/732200.png
#  - URL: mailto: 

## Categories

### Software/Hardware
# - **Add | Something here**:
#  - Icon: img/profile.jpg
#  - URL: https://url.com
#  - Description: 


### Free and Discounted stuff
# - **Add | Something here**:
#  - Icon: img/profile.jpg
#  - URL: https://url.com
#  - Description: 

### Learning
# - **Add | Something here**:
#  - Icon: img/profile.jpg
#  - URL: https://url.com
#  - Description: 
